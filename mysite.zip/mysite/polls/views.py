from django.http import HttpResponse
from django.shortcuts import render
from .models import Students


def index(request):
    #return HttpResponse("Hello, world. You're at the polls index.")
    student=Students.objects.get(pk=1)
    return render(request,'polls/index.html',{"stu":student,"num":10,"str":"sunck is a nice man","list":["good","nice","handsome"],"test":False,"code":"<h1>sunck is a very good man</h1>"})

def students(request):
    list=Students.objects.all()
    return render(request,'polls/index.html',{"students":list})

def good(request):
    return render(request,'polls/good.html')

def base_main(request):
    return render(request,'polls/base_main.html')

def detail(request):
    return render(request,'polls/detail.html')

def postfile(request):
    return render(request,'polls/postfile.html')
def showinfo(request):
    name=request.POST.get('username')
    pwd=request.POST.get('passwd')
    return render(request,'polls/showinfo.html',{"username":name,"passwd":pwd})

def attribles(request):
    print(request.path)
    print(request.method)
    print(request.encoding)
    print(request.GET)
    print(request.POST)
    print(request.FILES)
    print(request.COOKIES)
    print(request.session)
    return HttpResponse("attribles")

#获取get传递的数据
def get1(request):
    a=request.GET.get('a')
    b = request.GET.get('b')
    c = request.GET.get('c')
    return HttpResponse(a+"   "+b+"   "+c)
def get2(request):
    pass

#post
def showregist(request):
    return render(request,'polls/regist.html')
def regist(request):
    name=request.POST.get("name")
    gender = request.POST.get("gender")
    age = request.POST.get("age")
    hobby = request.POST.getlist("hobby")
    print(name)
    print(gender)
    print(age)
    print(hobby)
    return HttpResponse("post")

#response
def showresponse(request):
    res=HttpResponse()
    res.content=b'good'
    print(res.content)
    print(res.charset)
    print(res.status_code)
    print(res.content-type)
    return res

#cookies
def cookietest(request):
    res = HttpResponse()
    cookie=request.COOKIES
    res.write("<h1>"+cookie["sunck"]+"</h1>")
    #cookie=res.set_cookie("sunck","good")
    return res

#重定向
from django.http import HttpResponseRedirect
from django.shortcuts import redirect
def redirect1(request):
    return HttpResponseRedirect("/redirectl2")

def redirect2(request):
    return HttpResponse("我是重定向后的视图")


#session
def main(request):
    #取session
    username=request.session.get('name',"游客")
    return render(request,'polls/main.html',{'username':username})
def login(request):
    return render(request, 'polls/login.html')
def showmain(request):
    username=request.POST.get('username')
    #存储
    request.session['name']=username
    request.session.set_expiry(10)
    return redirect('/main/')
#from django.contrib.auth import logout
# def quit(request):
#     #清除session
#     logout(request)
#     return redirect('/main/')