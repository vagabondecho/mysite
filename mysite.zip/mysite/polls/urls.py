from django.conf.urls import include,url

from . import views

urlpatterns = [
    url(r'^$', views.index),

    url(r'^students/$', views.students),
    url(r'^good/$', views.good),

    url(r'^base_main/$',views.base_main),
    url(r'^detail/$',views.detail),

    url(r'^postfile/$',views.postfile),
    url(r'^showinfo/$',views.showinfo),

    url(r'^attribles',views.attribles),

    url(r'^get1/$',views.get1),
    url(r'^get2/$',views.get2),

    url(r'^showregist/$',views.showregist),
    url(r'^regist/$',views.regist),

    url(r'^showresponse',views.showresponse),

    url(r'^cookietest',views.cookietest),

    url(r'^redirect1/$',views.redirect1),
    url(r'^redirect2/$',views.redirect2),

    url(r'^main/$',views.main),
    url(r'^login/$',views.login),
    url(r'^show_main/$',views.showmain),



    # url(r'^quit/$',views.quit),
]

